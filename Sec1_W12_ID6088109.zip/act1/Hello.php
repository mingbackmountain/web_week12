<html>
<head>
</head>
<body>
<?php
    $greeting = "Hello World!";
    echo $greeting;
?>
</body>
</html>